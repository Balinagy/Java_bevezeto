package walking.game.player;

public class MadlyRotatingBuccaneer extends Player
{

    public MadlyRotatingBuccaneer()
    {
        super();
    }
}